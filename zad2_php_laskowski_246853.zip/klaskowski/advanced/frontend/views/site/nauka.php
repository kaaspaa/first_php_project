<?php

use yii\helpers\Html;

$this->title = 'Nauka';
$this->params['breadcrumbs'][] = ['label' => 'Nauka', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-nauka">
    
</div>