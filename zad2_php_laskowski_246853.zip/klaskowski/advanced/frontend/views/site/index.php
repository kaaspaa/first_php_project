<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\grid\GridView;

$this->title = 'Fiszki';
?>
<div class="site-index">

    <div class="body-content">
            <?php
      $kategoria=Yii::$app->request->get('kategoria');
      $podkategoria=Yii::$app->request->get('podkategoria');
      $zestaw=Yii::$app->request->get('zestaw');
    ?>

    <div class="container">

      <div class="row">
        <?php
          $rows = (new \yii\db\Query())
          ->select('*')
          ->from('kategoria')
          ->all();
          echo '<h2 class="text-left">Kategorie słówek:</h2>';
          echo '<div class="btn-group btn-group-vertical">'.' ';
          foreach ($rows as $row)
          {
            echo Html::a($row['nazwa'],['','kategoria'=>$row['id']],['class'=>'btn btn-info']);
          }
          echo '</div>';
        ?>
      </div>
      <br/>
      <div class="row" >
        <?php
          if (isset($kategoria))
          {
            $rows = (new \yii\db\Query())
            ->select('*')
            ->from('podkategoria')
            ->where('kategoria_id = '. $kategoria)
            ->all();
            echo '<h3 class="text-left">Podkategorie słówek:</h3>';
            echo '<div class="btn-group btn-group-vertical">'.' ';
            foreach ($rows as $row)
            {
              echo Html::a($row['nazwa'], ['/site/index', 'podkategoria' => $row['id']], ['class' => 'btn btn-primary']);
            }
            echo '</div>';
          }
        ?>
      </div>

      <div class="row" >
        <?php
          if (isset($podkategoria))
          {
            $rows = (new \yii\db\Query())
            ->select('*')
            ->from('zestaw')
            ->where('podkategoria_id = '. $podkategoria)
            ->all();
            echo '<h3 class="text-left">Podkategorie słówek:</h3>';
            echo '<div class="btn-group btn-group-vertical">'.' ';
            echo Html::a($row['nazwa'], ['/site/index', 'podkategoria' => $row['id']], ['class' => 'btn btn-primary']);
            echo '</div>';
            echo '<br/>';
            echo '<br/>';
            echo '<br/>';
            echo '<h4 class="text-left">Zestawy słówek:</h4>';
            echo '<div class="btn-group btn-group-vertical">'.' ';
            foreach ($rows as $row)
            {
              echo Html::a($row['nazwa'],['site/nauka', 'zestaw' => $row['id']], ['class' => 'btn btn-success']);
              /*<?= Html::a('Stwórz Kategorie', ['create'], ['class' => 'btn btn-success']) ?>
               * 
               */
            }
            echo '</div>';
          }
        ?>
    <br>
</div>
