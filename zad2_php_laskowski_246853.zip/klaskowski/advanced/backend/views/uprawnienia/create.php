<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Uprawnienia */

$this->title = 'Stwórz Uprawnienia';
$this->params['breadcrumbs'][] = ['label' => 'Uprawnienia', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uprawnienia-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'konto' => $konto,
        'podkategoria' => $podkategoria,
    ]) ?>

</div>
