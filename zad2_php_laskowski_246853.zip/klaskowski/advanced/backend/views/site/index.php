<?php

/* @var $this yii\web\View */

$this->title = 'Moja aplikacja Yii';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Gratulacje!</h1>

        <p class="lead">Udało ci się stworzyć aplikacje zasilaną Yii</p>

        <p><a class="btn btn-lg btn-success" href="http://www.yiiframework.com">Zacznij Yii</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Dokumentacja Yii</h2>

                <p>Dokumentacja Yii.</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/doc/">Yii Dokumentacja &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Yii forum</h2>

                <p>Jest zrobione po angielsku</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/forum/">Yii Forum &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Dodatki</h2>

                <p>Wszystko co mozesz chciec!</p>

                <p><a class="btn btn-default" href="http://www.yiiframework.com/extensions/">Yii Dodatki &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
