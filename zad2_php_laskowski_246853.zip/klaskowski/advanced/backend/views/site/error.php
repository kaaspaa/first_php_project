<?php

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = $name;
?>
<div class="site-error">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="alert alert-danger">
        <?= nl2br(Html::encode($message)) ?>
    </div>

    <p>
        Powyższy bład ukazał sie w czasie gdy server przetwarzal twoja prośbę.
    </p>
    <p>
        Skontaktuj się z nami jeśli sądzisz, że to był bład serwera. Dzięki.
    </p>

</div>
