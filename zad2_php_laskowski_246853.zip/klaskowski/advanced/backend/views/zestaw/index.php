<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\ZestawSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Zestaw';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="zestaw-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Stwórz Zestaw', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'user.username:text:Nazwa użytkownika',
            'jezyk1.nazwa:text:Z języka',
            'jezyk2.nazwa:text:Na język',
            'podkategoria.nazwa:text:Nazwa podkategorii',
            //'nazwa',
            //'zestaw:ntext',
            //'ilosc_slowek',
            //'data_dodania',
            //'data_edycji',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
